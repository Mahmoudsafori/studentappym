package com.example.studentapp2.model

data class Student(
    var id: String,
    var name: String,
    var isChecked: Boolean = false
) 